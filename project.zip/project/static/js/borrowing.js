// static/js/bookTable.js

function borrowBook(bookId) {
    fetch('/borrow-book/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')  // Function to get CSRF token, see below
        },
        body: JSON.stringify({ book_id: bookId })
    })
        .then(response => {
            if (response.ok) {
                alert('Book borrowed successfully');
                renderBookTable();  // Re-render the book table after borrowing
            } else {
                alert('Book is not available');
            }
        })
        .catch(error => {
            console.error('Error borrowing book:', error);
        });
}

// static/js/bookTable.js

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
