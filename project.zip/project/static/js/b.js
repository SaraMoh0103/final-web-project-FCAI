async function fetchBookData() {
    try {
        let response = await fetch(`/books/${bookId}`);
        if (response.ok) {
            let book = await response.json();
            return book;
        } else {
            console.error('Failed to fetch book data');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

async function fetchBorrowList() {
    try {
        let response = await fetch('/borrowed-books');
        if (response.ok) {
            let borrowList = await response.json();
            return borrowList;
        } else {
            console.error('Failed to fetch borrow list');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

async function addToBorrowList() {
    try {
        // Fetch current borrow list
        let borrowList = await fetchBorrowList();

        // Check if the book is already in the borrow list
        if (borrowList.some(b => b.id === bookId)) {
            window.alert("This book has already been borrowed");
            return;
        }

        // Fetch current book data
        let book = await fetchBookData();

        // Add new book to the borrow list
        let response = await fetch('/borrowed-books', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: bookId,
                name: book.bookName,
                category: book.category,
                author: book.author,
                img: book.img,
                price: book.price,
                language: book.language
            })
        });

        if (response.ok) {
            // Update the book's availability
            await fetch(`/books/${bookId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ available: false })
            });

            window.alert("Borrowed successfully");

            // Change the button text to reflect borrowing status
            borrowButton.textContent = "Borrowed";
            borrowButton.disabled = true;

            // Re-render the book details to reflect the updated availability
            renderBookDetails();
        } else {
            console.error('Failed to borrow the book');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
async function renderBookDetails() {
    try {
        // Fetch book data
        let book = await fetchBookData();

        // Determine the availability text based on the availability status
        let availabilityText = book.available ? 'available' : 'not available';

        // Generate HTML content to display the book details
        let cartona = `
        <h1>${book.bookName}</h1>
        <img src="${book.img}" alt="${book.bookName}">
        <pre>
          <b>Author</b>: ${book.author}
          <b>Category</b>: ${book.category}
          <b>Price</b>: ${"$" + book.price}
          <b>Availability</b>: ${availabilityText}
          <b>Language</b>: ${book.language}
          <h3>About the book:</h3> <p>${book.description}</p>
        </pre>`;

        // Update the bookShow element with the generated HTML content
        bookShow.innerHTML = cartona;

        // Fetch borrow list and update borrow button status
        let borrowList = await fetchBorrowList();
        if (borrowList.some(b => b.id === bookId)) {
            // If the book is already borrowed, update the button text and disable it
            borrowButton.textContent = "Borrowed";
            borrowButton.disabled = true;
        } else {
            // If the book is not borrowed, reset the button text and enable it
            borrowButton.textContent = "Borrow";
            borrowButton.disabled = false;
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Add an event listener to the borrow button to trigger borrowing process
borrowButton.addEventListener('click', addToBorrowList);

// Render the details of the selected book during initial setup
renderBookDetails();
