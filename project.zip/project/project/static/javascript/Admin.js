let bookId = document.getElementById("bookId")
let bookName = document.getElementById("bookName")
let author = document.getElementById("author")
let category = document.getElementById("category")
let language = document.getElementById("booklang")
let price = document.getElementById("bookPrice")
let description = document.getElementById("description")
let bookImg = document.getElementById("bookImg")
let addButton = document.getElementById("addButton")
let deleteButton = document.getElementById("deleteButton")
let deleteBookId = document.getElementById("deleteBookId")
let updateBookId = document.getElementById("updateBookId")
let updateBookName = document.getElementById("updateBookName")
let updateBookPrice = document.getElementById("updateBookButton")
let updateBookButton = document.getElementById("updateBookButton")

let dataContainer = []
function getOldData() {           
  if (dataContainer = []) {
    if (JSON.parse(localStorage.getItem('data')) == null) {
    }
    else {
      dataContainer = JSON.parse(localStorage.getItem('data'))
    }
  }
}
let data

addButton.addEventListener('click', function (e) {
  getOldData()
  data = {
    bookId: bookId.value,
    bookName: bookName.value,
    author: author.value,
    category: category.value,
    description: description.value,
    price: price.value,
    language: language.value,
    img: bookImg.value.split("\\")[2],
    available:true
  }
  dataContainer.push(data)
  localStorage.setItem('data', JSON.stringify(dataContainer))
  window.alert("added successfully")
})
deleteButton.addEventListener('click', function (e) {
  getOldData()
  let i = 0
  while ( i < dataContainer.length) {
    if (dataContainer[i].bookId == deleteBookId.value) {
      dataContainer.splice(i,1)
      console.log(dataContainer)
      window.alert('deleted successfully')
    }
    i++
  }
  localStorage.setItem('data', JSON.stringify(dataContainer))
})
updateBookButton.addEventListener('click', function (e) {
  getOldData()
  for (let i = 0; i < dataContainer.length; i++) {
    if (dataContainer[i].bookId == updateBookId.value) {
      console.log(updateBookName)
      dataContainer[i].bookName = updateBookName.value;
      dataContainer[i].price = updateBookPrice.value;
      localStorage.setItem('data', JSON.stringify(dataContainer))
      window.alert('updated successfully');
    }
  }
})