// Retrieve the book ID from localStorage and convert it to a number
let bookId = Number(localStorage.getItem('keyId'));

// Reference to the HTML element where book details will be displayed
let bookShow = document.getElementById('bookShow');

// Reference to the borrow button HTML element
let borrowButton = document.getElementById("borrowButton");

// Array to store book data retrieved from localStorage
let dataContainer = [];

// Function to retrieve previously stored book data from localStorage
function getOldData() {
  let storedData = localStorage.getItem('data');
  if (storedData) {
    dataContainer = JSON.parse(storedData);
  }
}

// Function to add the selected book to the borrow list
// Function to add the selected book to the borrow list
function addToBorrowList() {
  // Retrieve the borrow list from localStorage or initialize an empty array if it doesn't exist
  let borrowList = localStorage.getItem('borrowList');
  // Check if borrowList exists in localStorage
  if (borrowList) {
    // Parse the borrowList from JSON format to an array
    borrowList = JSON.parse(borrowList);
  } else {
    // If borrowList does not exist, initialize it as an empty array
    borrowList = [];
  }

  // Check if the book is already in the borrowList
  if (borrowList.some(b => b.id === bookId)) {
    window.alert("This book has already been borrowed");
    return;
  }

  // Get the current book data from the dataContainer
  let book = dataContainer[bookId];

  // Add new book to the borrow list
  borrowList.push({
    id: bookId,
    name: book.bookName,
    category: book.category,
    author: book.author,
    img: book.img,
    price: book.price,
    language: book.language
  });

  // Update the borrowList in localStorage
  localStorage.setItem('borrowList', JSON.stringify(borrowList));

  // Update the book's availability
  book.available = false;
  localStorage.setItem('data', JSON.stringify(dataContainer)); // Save updated data back to localStorage

  // Alert user about successful borrowing
  window.alert("Borrowed successfully");

  // Change the button text to reflect borrowing status
  borrowButton.textContent = "Borrowed";
  
  // Disable the borrow button
  borrowButton.disabled = true;

  // Re-render the book details to reflect the updated availability
  renderBookDetails();
}


// Function to render the details of the currently selected book
// Function to render the details of the currently selected book
function renderBookDetails() {
  // Retrieve the details of the selected book from the dataContainer
  let book = dataContainer[bookId];
  
  // Determine the availability text based on the availability status
  let availabilityText;
  if (book.available) {
    availabilityText = 'available';
  } else {
    availabilityText = 'not available';
  }

  // Generate HTML content to display the book details
  let cartona = `
    <h1>${book.bookName}</h1>
    <img src="${book.img}" alt="${book.bookName}">
    <pre>
      <b>Author</b>: ${book.author}
      <b>Category</b>: ${book.category}
      <b>Price</b>: ${"$"+book.price}
      <b>Availability</b>: ${availabilityText}
      <b>Language</b>: ${book.language}
      <h3>About the book:</h3> <p>${book.description}</p>
    </pre>`;

  // Update the bookShow element with the generated HTML content
  bookShow.innerHTML = cartona;

  // Check if the book is already borrowed
  let borrowList = localStorage.getItem('borrowList');
  if (borrowList) {
    borrowList = JSON.parse(borrowList);
    if (borrowList.some(b => b.id === bookId)) {
      // If the book is already borrowed, update the button text and disable it
      borrowButton.textContent = "Borrowed";
      borrowButton.disabled = true;
    } else {
      // If the book is not borrowed, reset the button text and enable it
      borrowButton.textContent = "Borrow";
      borrowButton.disabled = false;
    }
  } 
}

// Add an event listener to the borrow button to trigger borrowing process
borrowButton.addEventListener('click', addToBorrowList);

// Retrieve old data from localStorage during initial setup
getOldData();

// Render the details of the selected book during initial setup
renderBookDetails();
