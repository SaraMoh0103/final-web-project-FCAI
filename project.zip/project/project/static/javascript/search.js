async function searchBooks() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const searchCriteria = document.getElementById('searchCriteria').value;

    try {
        const response = await fetch(`/api/search_books/?search_term=${encodeURIComponent(searchTerm)}&search_criteria=${encodeURIComponent(searchCriteria)}`);
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        const data = await response.json();
        displayBooks(data.books);
    } catch (error) {
        console.error('Failed to search books:', error);
    }
}

function displayBooks(books) {
    const bookDetailsDiv = document.getElementById('bookDetails');
    bookDetailsDiv.innerHTML = '';

    if (books.length === 0) {
        bookDetailsDiv.innerHTML = 'No books found.';
    } else {
        books.forEach(book => {
            const bookDiv = document.createElement('div');
            bookDiv.innerHTML = `
                <h2>${book.book_name}</h2>
                <p>Author: ${book.author}</p>
                <p>Category: ${book.category}</p>
                <p>Language: ${book.language}</p>
                <p>Price: ${book.price}</p>
                <p>Description: ${book.description || 'No description available'}</p>
                <p>Status: ${book.available ? 'Available' : 'Not Available'}</p>
                ${book.book_img ? `<img src="${book.book_img}" alt="${book.book_name}">` : ''}
                <hr>
            `;
            bookDetailsDiv.appendChild(bookDiv);
        });
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const searchButton = document.getElementById('button');
    searchButton.addEventListener('click', searchBooks);
});