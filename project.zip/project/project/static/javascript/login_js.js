// let form = document.getElementById('form');
// let Username= document.getElementById('Username');
// let Password= document.getElementById('Password');
// let loginBtn = document.getElementById('loginBtn') ;




// if (JSON.parse(localStorage.getItem('users')) == null) { 
//     users = [] ;
// } else { 
//      users = JSON.parse(localStorage.getItem('users')) ;
// } 
// let flag=false;
// loginBtn.addEventListener('click',function(e) {
//     let validation=false;
//     if (Username.value.length!=0 && Password.value.length!=0){
//         validation=true;
//        }
//      for (let i = 0; (i < users.length && validation); i++) { 
//     if (Username.value === users[i].User_name && Password.value === users[i].Pass) {
//         flag=true;
//         if (flag===true){
//             window.alert('login successfully'); 
//             if (users[i].is_admin===true) { 
//                 console.log("admin");
//                 window.open('admin ver/homepage.html'); 
//             } else { 
//                 console.log("user");
//                 window.open('user ver/homepage.html');
//             }
//         break; 
//         }
        


//     }
 

//    }
  
//    if (flag===false || validation==false) {
//     window.alert('wrong username or password');
//     e.preventDefault();
//    }
// });



// // function submit(){
// //     let form = document.getElementById('form').value;
// // let Username= document.getElementById('Username').value;
// // let Password= document.getElementById('Password').value;

// // }