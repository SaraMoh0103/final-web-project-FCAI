// let checkAdmin = false;    ///determine admin or not 
// let signupBtn = document.getElementById("signupBtn"); //btn
// let flagg=false;

// signupBtn.addEventListener('click' , function(e){
//     let Username= document.getElementById('username').value;
//     let Password= document.getElementById('password').value;
//     let confiremedPass = document.getElementById('confirmingpass').value;
//     let Email =document.getElementById('email').value;
//     let Is_Admin = document.getElementById('admin');
    


//     let username_valid=false;
//     let pass_valid=false;
//     let conf_valid =false;
//     let email_valid=false;
 
//     if (Username.length>8){
//          username_valid=true;
//     }
 
//     if (Password.length>8 && Password.length<15){
//          pass_valid=true;
//     }
 
//     if (Password===confiremedPass)
//         conf_valid=true;
 
 
//     if (Email.length!=0)
//         email_valid=true;

//      if(Is_Admin.checked){
//             checkAdmin = true;
//          }
 
//       if (username_valid!=false && pass_valid!=false && conf_valid!=false && email_valid!=false ){ //and not or
//         flagg=true; 
//          let newUser= {
//              User_name: Username,
//              Pass: Password,
//              email: Email,
//              is_admin: checkAdmin
//          };
//          if (JSON.parse(localStorage.getItem('users')) == null) { 
//              users = [] ; //empty array
//          } else { 
//               users = JSON.parse(localStorage.getItem('users')) 
//          } 
         
//          users.push(newUser);
//          localStorage.setItem("users",JSON.stringify(users));
//          console.log("doneee");
//          console.log(JSON.parse(localStorage.getItem('users')));

//          console.log(checkAdmin);
//          return true;
// }
// });

// // function submit (){
// //     let Username= document.getElementById('username').value;
// //     let Password= document.getElementById('password').value;
// //     let confiremedPass = document.getElementById('confirmingpass').value;
// //     let Email =document.getElementById('email').value;
// //     let Is_Admin = document.getElementById('admin');
    


// //     let username_valid=false;
// //     let pass_valid=false;
// //     let conf_valid =false;
// //     let email_valid=false;
 
// //     if (Username.length>8){
// //          username_valid=true;
// //     }
 
// //     if (Password.length>8 && Password.length<15){
// //          pass_valid=true;
// //     }
 
// //     if (Password===confiremedPass)
// //         conf_valid=true;
 
 
// //     if (Email.length!=0)
// //         email_valid=true;

// //      if(Is_Admin.checked){
// //             checkAdmin = true;
// //          }
 
// //       if (username_valid!=false && pass_valid!=false && conf_valid!=false && email_valid!=false ){ //and not or 
// //          let newUser= {
// //              User_name: Username,
// //              Pass: Password,
// //              email: Email,
// //              is_admin: checkAdmin
// //          };
// //          if (JSON.parse(localStorage.getItem('users')) == null) { 
// //              users = [] ; //empty array
// //          } else { 
// //               users = JSON.parse(localStorage.getItem('users')) 
// //          } 
         
// //          users.push(newUser);
// //          localStorage.setItem("users",JSON.stringify(users));
// //          console.log("doneee");
// //          console.log(JSON.parse(localStorage.getItem('users')));

// //          console.log(checkAdmin);
// // }
     
        

// // }

// // signupBtn.addEventListener('click' , submit);


// signupBtn.addEventListener('click' , function(e){
//     if (flagg===false){
//         e.preventDefault();
//         return false;
//     }
//     if(checkAdmin == true){
//         console.log("admin");
//         window.open('admin ver/homepage.html', '_blank');
//     }
//     else if(checkAdmin == false){
//         console.log("user");
//         window.open('user ver/homepage.html', '_blank');
//     }
// }
// )


// // form.onsubmit=function clicked(e){ // when click
// //    let username_valid=false;
// //    let pass_valid=false;
// //    let conf_valid =false;
// //    let email_valid=false;

// //    if (Username.value.length>8){
// //         username_valid=true;
// //    }

// //    if (Password.value.length>8 && Password.value.length<15){
// //         pass_valid=true;
// //    }

// //    if (Password.value===confiremedPass.value)
// //        conf_valid=true;


// //    if (Email.value.length!=0)
// //        email_valid=true;

// //      if (username_valid!=false || pass_valid!=false || conf_valid!=false || email_valid!=false ){ //and not or 
// //         let newUser= {
// //             User_name: Username.value,
// //             Pass: Password.value,
// //             email: Email.value,
// //             is_admin: Is_Admin.value
// //         };
// //         if (JSON.parse(localStorage.getItem('users')) == null) { 
// //             users = [] ; //empty array
// //         } else { 
// //              users = JSON.parse(localStorage.getItem('users')) 
// //         } 
        
// //         users.push(newUser);
// //         localStorage.setItem("users",JSON.stringify(users));
    
// //         // console.log(JSON.parse(localStorage.getItem(users)));

// //         if(Is_Admin.checked){
// //             checkAdmin = true;
// //         }
// //         console.log(checkAdmin);
// //         if(checkAdmin){
// //             window.location.href = 'file:///C:\Users\Mariam Omar\Desktop\sara\Web Projectv8 (2)\Web Projectv8\admin ver\homepage.html';
// //         }else{
// //             window.location.href = 'file:///C:\Users\Mariam Omar\Desktop\sara\Web Projectv8 (2)\Web Projectv8\admin ver\homepage.html';
// //         }
// //    }
// //    else {
// //        e.preventDefault();
// //    }

// // };