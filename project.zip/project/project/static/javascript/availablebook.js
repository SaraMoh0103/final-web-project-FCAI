let dataContainer = [];

// Function to retrieve book data from localStorage
function getBookData() {
  const storedData = localStorage.getItem('data');
  if (storedData) {
    dataContainer = JSON.parse(storedData);
  }
}

// Function to render the book table
function renderBookTable() {
  const bookTableBody = document.getElementById('bookTableBody');
  bookTableBody.innerHTML = '';

  dataContainer.forEach((book, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${book.bookId}</td>
      <td>${book.bookName}</td>
      <td>${book.author}</td>
      <td>${book.category}</td>
      <td>${book.language}</td>
      <td>${book.price}</td>
      <td>
        <button onclick="goToEditBook(${index})">Edit</button>
        <button onclick="deleteBook(${index})">Delete</button>
      </td>
    `;
    bookTableBody.appendChild(row);
  });
}

// Function to delete a book
function deleteBook(index) {
  dataContainer.splice(index, 1);
  localStorage.setItem('data', JSON.stringify(dataContainer));
  renderBookTable();
}

// Function to navigate to the edit book page
function goToEditBook(index) {
  localStorage.setItem('editBookIndex', index);
  window.location.href = 'edit.html';
}

// Retrieve book data from localStorage and render the table
getBookData();
renderBookTable();