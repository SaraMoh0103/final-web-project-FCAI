let parentBook = document.getElementById("books")
let dataContainer = []
let cartona = ``
console.log(cartona)
function getOldData() {
  if (dataContainer = []) {
      if (JSON.parse(localStorage.getItem('data')) == null) {
      }
      else {
        dataContainer = JSON.parse(localStorage.getItem('data'))
      }
    }
  }
   function showdata(){
    getOldData()
    for (let i = 0; i < dataContainer.length; i++) {
      if (dataContainer[i].category == "Fantasy") {
        cartona += `<br>
        <a href="book.html"  class="bookLink" id="${i}">
        <div class="book">
        <h2> ${dataContainer[i].bookName}</h2>
        <img src="${dataContainer[i].img}" width="250" height="400">
        </div>
        </a>
        `
      }
    }
    parentBook.innerHTML = cartona
    }
 showdata()
