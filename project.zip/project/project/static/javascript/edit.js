let dataContainer = [];

// Function to retrieve book data from localStorage
function getBookData() {
  const storedData = localStorage.getItem('data');
  if (storedData) {
    dataContainer = JSON.parse(storedData);
  }
}

// Function to populate the form fields with book data
function populateFormFields() {
  const index = localStorage.getItem('editBookIndex');
  const book = dataContainer[index];

  document.getElementById('bookId').value = book.bookId;
  document.getElementById('bookName').value = book.bookName;
  document.getElementById('author').value = book.author;
  document.getElementById('category').value = book.category;
  document.getElementById('language').value = book.language;
  document.getElementById('price').value = book.price;
}

// Function to update the book data
function updateBookData(event) {
  event.preventDefault();

  const index = localStorage.getItem('editBookIndex');
  const book = dataContainer[index];

  book.bookName = document.getElementById('bookName').value;
  book.author = document.getElementById('author').value;
  book.category = document.getElementById('category').value;
  book.language = document.getElementById('language').value;
  book.price = document.getElementById('price').value;

  localStorage.setItem('data', JSON.stringify(dataContainer));
  window.location.href = 'availablebooks.html';
}

// Function to handle form submission
function handleFormSubmit(event) {
  event.preventDefault();
  updateBookData(event);
}

// Retrieve book data from localStorage
getBookData();

// Populate the form fields with book data
populateFormFields();

// Add event listener to the form submission
document.getElementById('editBookForm').addEventListener('submit', handleFormSubmit);