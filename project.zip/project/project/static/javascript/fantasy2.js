a = document.querySelectorAll("a.bookLink")
for (let i = 0; i < a.length; i++) {
    a[i].addEventListener('click',function(e){
        id = a[i].id
        localStorage.setItem('keyId',id)
    });
    
}