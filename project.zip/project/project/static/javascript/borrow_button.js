// Function to display borrowed books when the window loads
window.onload = function displayBorrowedBooks() {
  // Retrieve borrowed books from localStorage or initialize an empty array if not present
  let borrowedBooks = JSON.parse(localStorage.getItem('borrowList')) || [];

  // Reference to the HTML element where borrowed books will be displayed
  let displayContainer = document.getElementById('borrowedList');

  // Check if there are any borrowed books
  if (borrowedBooks.length === 0) {
    // If no borrowed books, display a message indicating so
    displayContainer.innerHTML = "<p>No books borrowed yet.</p>";
  } else {
    // If there are borrowed books, generate HTML content to display each book
    let contentHTML = borrowedBooks.map(book => {
      return `
        <div class="borrow">
          <h2>${book.name}</h2>
          <img src="${book.img}" alt="${book.bookName}">
          <p><b>Author:</b> ${book.author}</p>
          <p><b>Category:</b> ${book.category}</p>
          <b>Price</b>: ${"$"+ book.price}</p>
          <b>Language</b>: ${book.language}</p>
        </div>
        <br>
      `;
    }).join('');
    // Update the displayContainer with the generated HTML content
    displayContainer.innerHTML = contentHTML;
  }
};
