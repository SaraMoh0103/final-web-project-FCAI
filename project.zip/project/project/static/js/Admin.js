// JavaScript code

document.addEventListener('DOMContentLoaded', function () {
  let addButton = document.getElementById("addButton");
  let deleteButton = document.getElementById("deleteButton");
  let addBookForm = document.getElementById("addBookForm");
  let deleteBookForm = document.getElementById("deleteBookForm");

  addButton.addEventListener('click', function () {
      let form_data = new FormData(addBookForm);
      fetch('/services/', {
          method: 'POST',
          body: form_data,
          headers: {
              'X-CSRFToken': getCookie('csrftoken')
          },
          credentials: 'same-origin'
      })
      .then(response => response.json())
      .then(data => {
          alert(data.message);
          // Reload the page or update the UI as needed
      })
      .catch(error => console.error('Error:', error));
  });

  deleteButton.addEventListener('click', function () {
      let form_data = new FormData(deleteBookForm);
      fetch('/services/', {
          method: 'POST',
          body: form_data,
          headers: {
              'X-CSRFToken': getCookie('csrftoken')
          },
          credentials: 'same-origin'
      })
      .then(response => response.json())
      .then(data => {
          alert(data.message);
          // Reload the page or update the UI as needed
      })
      .catch(error => console.error('Error:', error));
  });

  // Function to get CSRF token
  function getCookie(name) {
      let cookieValue = null;
      if (document.cookie && document.cookie !== '') {
          const cookies = document.cookie.split(';');
          for (let i = 0; i < cookies.length; i++) {
              const cookie = cookies[i].trim();
              // Does this cookie string begin with the name we want?
              if (cookie.substring(0, name.length + 1) === (name + '=')) {
                  cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                  break;
              }
          }
      }
      return cookieValue;
  }
});