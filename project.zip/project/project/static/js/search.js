

// function getOldData() {           
 
    
//      return JSON.parse(localStorage.getItem('data'))
    
  
// }


// function displayBooks(books) {
//   const bookDetailsDiv = document.getElementById('bookDetails');
//   bookDetailsDiv.innerHTML = '';

//   if (books.length === 0) {
//     bookDetailsDiv.innerHTML = 'No books found.';
//   } else {
//     books.forEach(book => {
//       const bookDiv = document.createElement('div');
//       bookDiv.innerHTML = `
//         <h2>${book.title}</h2>
//         <p>Author: ${book.author}</p>
//         <p>Category: ${book.category}</p>
//         <hr>
//       `;
//       bookDetailsDiv.appendChild(bookDiv);
//     });
//   }
// }
// // function searchBooks() {
// //   console.log("Search function is being executed."); // Add this line
// //   const searchTerm = document.getElementById('searchInput').value.toLowerCase();
// //   const books = getOldData();
// //   const filteredBooks = books.filter(book => 
// //     book.title.toLowerCase().includes(searchTerm) ||
// //     book.author.toLowerCase().includes(searchTerm) ||
// //     book.category.toLowerCase().includes(searchTerm)
// //   );

// //   displayBooks(filteredBooks);
// // }
// // function searchBooks() {
// //   console.log("Search function is being executed.");
// //   const searchTerm = document.getElementById('searchInput').value.toLowerCase();
// //   const books = getOldData();

// //   const filteredBooks = books.filter(book => {
// //     // Ensure that title, author, and category properties exist before calling toLowerCase()
// //     const title = book.title ? book.title.toLowerCase() : '';
// //     const author = book.author ? book.author.toLowerCase() : '';
// //     const category = book.category ? book.category.toLowerCase() : '';

// //     return title.includes(searchTerm) || author.includes(searchTerm) || category.includes(searchTerm);
// //   });

// //   displayBooks(filteredBooks);
// // }
// function searchBooks() {
//   console.log("Search function is being executed.");
//   const searchTerm = document.getElementById('searchInput').value.toLowerCase();
//   console.log("Search Term:", searchTerm); // Log search term
//   const books = getOldData();
//   console.log("Books:", books); // Log books array

//   const filteredBooks = books.filter(book => {
//     // Ensure that the property exists before calling toLowerCase()
//     const property = book.title ? book.title.toLowerCase() : 
//                      book.author ? book.author.toLowerCase() :
//                      book.category ? book.category.toLowerCase() : '';

//     console.log('Property:', property);

//     return property.includes(searchTerm);
//   });

//   displayBooks(filteredBooks);
// }



// // Add event listener to the search button
// document.addEventListener('DOMContentLoaded', function () {
//   const searchButton = document.querySelector('button');
//   searchButton.addEventListener('click', searchBooks);
// });

function getOldData() {           
  return JSON.parse(localStorage.getItem('data')) || [];
}


// function displayBooks(books) {
//   const bookDetailsDiv = document.getElementById('bookDetails');
//   bookDetailsDiv.innerHTML = '';

//   if (books.length === 0) {
//     bookDetailsDiv.innerHTML = 'No books found.';
//   } else {
//     books.forEach(book => {
//       const bookDiv = document.createElement('div');
//       bookDiv.innerHTML = `
//         <h2>${book.bookName}</h2> <!-- Display 'bookName' instead of 'title' -->
//         <p>Author: ${book.author}</p>
//         <p>Category: ${book.category}</p>

//         <p>Book Status: ${book.bookStatus}</p>

//         <hr>
//       `;
//       bookDetailsDiv.appendChild(bookDiv);
//     });
//   }
// }

function displayBooks(books) {
  const bookDetailsDiv = document.getElementById('bookDetails');
  bookDetailsDiv.innerHTML = '';

  if (books.length === 0) {
    bookDetailsDiv.innerHTML = 'No books found.';
  } else {
    books.forEach(book => {
      const bookDiv = document.createElement('div');
      bookDiv.innerHTML = `
        <h2>${book.bookName}</h2>
        <p>Author: ${book.author}</p>
        <p>Category: ${book.category}</p>
        <p>Description: ${book.description}</p> 
        <p>Status: ${book.bookStatus}</p> 
        <p>Price: ${book.bookPrice}</p> 
        <hr>
      `;
      bookDetailsDiv.appendChild(bookDiv);
    });
  }
}


function searchBooks() {
  console.log("Search function is being executed.");
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  console.log("Search Term:", searchTerm);
  const books = getOldData();
  console.log("Books:", books);

  const searchCriteria = document.getElementById('searchCriteria').value;
  console.log("Search Criteria:", searchCriteria); // Log search criteria

  const filteredBooks = books.filter(book => {
    let property = '';
    if (searchCriteria === 'title' && book.hasOwnProperty('bookName')) {
      property = book.bookName.toLowerCase(); // Use 'bookName' property for title
    } else {
      property = book[searchCriteria] ? book[searchCriteria].toLowerCase() : '';
    }
    console.log('Property:', property);
    return property.includes(searchTerm);
  });

  displayBooks(filteredBooks);
}



document.addEventListener('DOMContentLoaded', function () {
  const searchButton = document.querySelector('button');
  searchButton.addEventListener('click', searchBooks);
});
